# A simple vm server calculator.

##Installation

1- `composer install`

2- `php index.php`

3- `profit`

**Mirza Zeyrek**